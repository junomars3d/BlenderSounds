import bpy
import aud
import threading
import os


bl_info = {
    "name": "Whatsupguys Sound Player",
    "author": "Your Name",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "description": "Plays a sound file from the addon directory",
    "category": "Object",
}

def play_mp3(mp3_path):
    # Load and play the sound in a separate thread
    def play_sound():
        sound = aud.Sound(mp3_path)
        device = aud.Device()
        handle = device.play(sound)
        while handle.status:
            pass

    threading.Thread(target=play_sound).start()

class JunoToolsPanel(bpy.types.Panel):
    bl_label = "Whatsupguys"
    bl_idname = "PT_JunoTools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'JunoTools'

    def draw(self, context):
        layout = self.layout
        layout.operator("wm.play_mp3_button")

class WM_OT_PlayMP3Button(bpy.types.Operator):
    bl_label = "Play Sound"
    bl_idname = "wm.play_mp3_button"

    def execute(self, context):
        # Find the add-on's installation path
        addon_path = os.path.dirname(__file__)
        mp3_path = os.path.join(addon_path, "wugs.mp3")
        print("MP3 Path:", mp3_path)  # Print the path for debugging
        play_mp3(mp3_path)
        return {'FINISHED'}

def register():
    bpy.utils.register_class(JunoToolsPanel)
    bpy.utils.register_class(WM_OT_PlayMP3Button)

def unregister():
    bpy.utils.unregister_class(JunoToolsPanel)
    bpy.utils.unregister_class(WM_OT_PlayMP3Button)

if __name__ == "__main__":
    register()
